<div id="sidebar" class="sidebar">
    <button id="toggleSidebar" class="btn btn-primary">☰</button>
    <nav>
        <ul>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="pages/create.php">Tambah Mahasiswa</a></li>
            <li><a href="#">Laporan</a></li>
            <li><a href="#">Pengaturan</a></li>
        </ul>
    </nav>
</div>