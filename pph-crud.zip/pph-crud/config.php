<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'rangga');
define('DB_PASS', 'rangga');
define('DB_NAME', 'avengers');
define('DB_CHARSET', 'utf8mb4');
