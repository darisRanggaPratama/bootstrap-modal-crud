<div class="sidebar" id="sidebar">
    <div class="d-flex flex-column flex-shrink-0 p-3 text-white">
        <span class="fs-4 mb-3">Malea Energy</span>
        <hr>
        <ul class="nav nav-pills flex-column mb-auto">
            <li class="nav-item">
                <a href="index.php" class="nav-link sidebar-link active">
                    <i class="bi bi-house me-2"></i>
                    Home
                </a>
            </li>
            <li>
                <a href="page1.php" class="nav-link sidebar-link">
                    <i class="bi bi-file-text me-2"></i>
                    Page 1
                </a>
            </li>
            <li>
                <a href="page2.php" class="nav-link sidebar-link">
                    <i class="bi bi-file-text me-2"></i>
                    Page 2
                </a>
            </li>
        </ul>
    </div>
</div>
