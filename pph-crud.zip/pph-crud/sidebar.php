<div class="sidebar" id="sidebar">
    <div class="d-flex flex-column flex-shrink-0 p-3 text-white">
        <span class="fs-4 mb-3">Malea Energy</span>
        <hr>
        <ul class="nav nav-pills flex-column mb-auto">
            <li>
                <!-- Refresh Button Added -->
                <a class="nav-link sidebar-link" id="refreshButton">
                    <i class="bi bi-arrow-clockwise"></i> Refresh
                </a>
            </li>
            <li class="nav-item">
                <a href="home.php" class="nav-link sidebar-link active">
                    <i class="bi bi-house me-2"></i>
                    Home
                </a>
            </li>
            <li>
                <a href="logout.php" class="nav-link sidebar-link">
                    <i class="bi bi-box-arrow-right me-2"></i>
                    Sign Out
                </a>
            </li>
        </ul>
    </div>
</div>
