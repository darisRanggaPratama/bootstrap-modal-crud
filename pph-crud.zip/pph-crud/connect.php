<?php
// Connection details
$server = 'localhost'; // Server name
$user = 'rangga'; // User name
$password = 'rangga'; // User password
$database = 'avengers'; // Database name

// Connection to database
$connect = mysqli_connect($server, $user, $password, $database);
