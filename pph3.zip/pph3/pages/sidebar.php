<!-- includes/sidebar.php -->
<div id="sidebar" class="col-md-2 bg-light sidebar">
    <div class="sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="../index.php">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="create.php">Tambah Data</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../search.php">Cari Data</a>
            </li>
        </ul>
    </div>
</div>
<button id="sidebar-toggle" class="btn btn-primary sidebar-toggle">☰</button>

